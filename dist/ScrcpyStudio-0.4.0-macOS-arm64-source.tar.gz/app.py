#!/usr/bin/env python3
"""Scrcpy Studio 入口。"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PySide6.QtGui import QFont  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from core.config import load_state  # noqa: E402
from ui import style  # noqa: E402
from ui.main_window import MainWindow  # noqa: E402


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Scrcpy Studio")
    app.setApplicationDisplayName("Scrcpy Studio")
    app.setApplicationVersion("0.4.0")
    # 悬浮球模式下主窗口会隐藏，此时不能让 Qt 因为「最后一个窗口关闭」而退出
    app.setQuitOnLastWindowClosed(False)
    font = QFont("PingFang SC")
    font.setPixelSize(13)
    app.setFont(font)

    style.apply(app, load_state().theme)

    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
